/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define Photodiode_Input_TRIS                 TRISAbits.TRISA0
#define Photodiode_Input_LAT                  LATAbits.LATA0
#define Photodiode_Input_PORT                 PORTAbits.RA0
#define Photodiode_Input_WPU                  WPUAbits.WPUA0
#define Photodiode_Input_OD                   ODCONAbits.ODCA0
#define Photodiode_Input_ANS                  ANSELAbits.ANSELA0
#define Photodiode_Input_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define Photodiode_Input_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define Photodiode_Input_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define Photodiode_Input_GetValue()           PORTAbits.RA0
#define Photodiode_Input_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define Photodiode_Input_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define Photodiode_Input_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define Photodiode_Input_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define Photodiode_Input_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define Photodiode_Input_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define Photodiode_Input_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define Photodiode_Input_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA2 aliases
#define Subsystem_Output_TRIS                 TRISAbits.TRISA2
#define Subsystem_Output_LAT                  LATAbits.LATA2
#define Subsystem_Output_PORT                 PORTAbits.RA2
#define Subsystem_Output_WPU                  WPUAbits.WPUA2
#define Subsystem_Output_OD                   ODCONAbits.ODCA2
#define Subsystem_Output_ANS                  ANSELAbits.ANSELA2
#define Subsystem_Output_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define Subsystem_Output_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define Subsystem_Output_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define Subsystem_Output_GetValue()           PORTAbits.RA2
#define Subsystem_Output_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define Subsystem_Output_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define Subsystem_Output_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define Subsystem_Output_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define Subsystem_Output_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define Subsystem_Output_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define Subsystem_Output_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define Subsystem_Output_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RB1 aliases
#define DebugLED_Output_TRIS                 TRISBbits.TRISB1
#define DebugLED_Output_LAT                  LATBbits.LATB1
#define DebugLED_Output_PORT                 PORTBbits.RB1
#define DebugLED_Output_WPU                  WPUBbits.WPUB1
#define DebugLED_Output_OD                   ODCONBbits.ODCB1
#define DebugLED_Output_ANS                  ANSELBbits.ANSELB1
#define DebugLED_Output_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define DebugLED_Output_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define DebugLED_Output_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define DebugLED_Output_GetValue()           PORTBbits.RB1
#define DebugLED_Output_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define DebugLED_Output_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define DebugLED_Output_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define DebugLED_Output_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define DebugLED_Output_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define DebugLED_Output_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define DebugLED_Output_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define DebugLED_Output_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RC7 aliases
#define PushButton_Input_TRIS                 TRISCbits.TRISC7
#define PushButton_Input_LAT                  LATCbits.LATC7
#define PushButton_Input_PORT                 PORTCbits.RC7
#define PushButton_Input_WPU                  WPUCbits.WPUC7
#define PushButton_Input_OD                   ODCONCbits.ODCC7
#define PushButton_Input_ANS                  ANSELCbits.ANSELC7
#define PushButton_Input_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define PushButton_Input_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define PushButton_Input_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define PushButton_Input_GetValue()           PORTCbits.RC7
#define PushButton_Input_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define PushButton_Input_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define PushButton_Input_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define PushButton_Input_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define PushButton_Input_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define PushButton_Input_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define PushButton_Input_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define PushButton_Input_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set RD5 aliases
#define JT_Input_TRIS                 TRISDbits.TRISD5
#define JT_Input_LAT                  LATDbits.LATD5
#define JT_Input_PORT                 PORTDbits.RD5
#define JT_Input_WPU                  WPUDbits.WPUD5
#define JT_Input_OD                   ODCONDbits.ODCD5
#define JT_Input_ANS                  ANSELDbits.ANSELD5
#define JT_Input_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define JT_Input_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define JT_Input_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define JT_Input_GetValue()           PORTDbits.RD5
#define JT_Input_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define JT_Input_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define JT_Input_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define JT_Input_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define JT_Input_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define JT_Input_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define JT_Input_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define JT_Input_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set RF0 aliases
#define IO_RF0_TRIS                 TRISFbits.TRISF0
#define IO_RF0_LAT                  LATFbits.LATF0
#define IO_RF0_PORT                 PORTFbits.RF0
#define IO_RF0_WPU                  WPUFbits.WPUF0
#define IO_RF0_OD                   ODCONFbits.ODCF0
#define IO_RF0_ANS                  ANSELFbits.ANSELF0
#define IO_RF0_SetHigh()            do { LATFbits.LATF0 = 1; } while(0)
#define IO_RF0_SetLow()             do { LATFbits.LATF0 = 0; } while(0)
#define IO_RF0_Toggle()             do { LATFbits.LATF0 = ~LATFbits.LATF0; } while(0)
#define IO_RF0_GetValue()           PORTFbits.RF0
#define IO_RF0_SetDigitalInput()    do { TRISFbits.TRISF0 = 1; } while(0)
#define IO_RF0_SetDigitalOutput()   do { TRISFbits.TRISF0 = 0; } while(0)
#define IO_RF0_SetPullup()          do { WPUFbits.WPUF0 = 1; } while(0)
#define IO_RF0_ResetPullup()        do { WPUFbits.WPUF0 = 0; } while(0)
#define IO_RF0_SetPushPull()        do { ODCONFbits.ODCF0 = 0; } while(0)
#define IO_RF0_SetOpenDrain()       do { ODCONFbits.ODCF0 = 1; } while(0)
#define IO_RF0_SetAnalogMode()      do { ANSELFbits.ANSELF0 = 1; } while(0)
#define IO_RF0_SetDigitalMode()     do { ANSELFbits.ANSELF0 = 0; } while(0)

// get/set RF1 aliases
#define IO_RF1_TRIS                 TRISFbits.TRISF1
#define IO_RF1_LAT                  LATFbits.LATF1
#define IO_RF1_PORT                 PORTFbits.RF1
#define IO_RF1_WPU                  WPUFbits.WPUF1
#define IO_RF1_OD                   ODCONFbits.ODCF1
#define IO_RF1_ANS                  ANSELFbits.ANSELF1
#define IO_RF1_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define IO_RF1_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define IO_RF1_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define IO_RF1_GetValue()           PORTFbits.RF1
#define IO_RF1_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define IO_RF1_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define IO_RF1_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define IO_RF1_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define IO_RF1_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define IO_RF1_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define IO_RF1_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define IO_RF1_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/