So i fixed the pins here for this code and can guarantee a signal is being sent out from TX, but i cannot guarantee the RX is working. If i hook TX to RX on my board, can i test it in that way?

# main.py
# ESP32-S3 MicroPython
# Buttons: GPIO9, GPIO11, GPIO13
# OLED I2C: SCL=GPIO38, SDA=GPIO39
# LED: GPIO15 toggles on each button press

from machine import Pin, I2C, UART
import time
import ssd1306

DEBOUNCE_MS = 40
POLL_MS = 5

BTN1_PIN = 9
BTN2_PIN = 11
BTN3_PIN = 13

SCL_PIN = 38
SDA_PIN = 39

LED_PIN = 15

OLED_WIDTH = 128
OLED_HEIGHT = 64
OLED_ADDR = 0x3C

# Set these to the actual ESP32-S3 GPIO numbers that correspond to RF0 / RF1
UART_RX_PIN = 44
UART_TX_PIN = 43

TX_MSG = "AZCTHelloYB"


class DebouncedInput:
    def __init__(self, pin_num, debounce_ms=DEBOUNCE_MS):
        self.pin = Pin(pin_num, Pin.IN, Pin.PULL_DOWN)
        self.debounce_ms = debounce_ms
        self._stable_state = self.pin.value()
        self._last_raw = self._stable_state
        self._last_change = time.ticks_ms()

    def update(self, now_ms):
        raw = self.pin.value()

        if raw != self._last_raw:
            self._last_raw = raw
            self._last_change = now_ms

        if raw != self._stable_state:
            if time.ticks_diff(now_ms, self._last_change) >= self.debounce_ms:
                self._stable_state = raw
                return self._stable_state  # 1 = pressed, 0 = released

        return None


def toggle_led(led_pin):
    led_pin.value(0 if led_pin.value() else 1)


def show_text(oled, text):
    oled.fill(0)
    oled.text(text, 0, 0)
    oled.show()


# Inputs
btn1 = DebouncedInput(BTN1_PIN)
btn2 = DebouncedInput(BTN2_PIN)
btn3 = DebouncedInput(BTN3_PIN)

# LED
led = Pin(LED_PIN, Pin.OUT)
led.value(0)

# I2C + OLED
i2c = I2C(0, scl=Pin(SCL_PIN), sda=Pin(SDA_PIN), freq=100000)
oled = ssd1306.SSD1306_I2C(OLED_WIDTH, OLED_HEIGHT, i2c, addr=OLED_ADDR)

# UART
uart = UART(2, baudrate=9600, tx=Pin(UART_TX_PIN), rx=Pin(UART_RX_PIN))
rx_buf = b""

show_text(oled, "Ready")

while True:
    now = time.ticks_ms()

    e1 = btn1.update(now)
    e2 = btn2.update(now)
    e3 = btn3.update(now)

    if uart.any():
        data = uart.read()
        if data:
            rx_buf += data

            while b"\n" in rx_buf:
                line, rx_buf = rx_buf.split(b"\n", 1)
                line = line.rstrip(b"\r")
                text = line.decode("utf-8", "ignore")
                print("RX:", text)

                oled.fill(0)
                oled.text("RX:", 0, 0)
                oled.text(text[:16], 0, 16)
                oled.show()
                
                

    if e1 == 1:
        uart.write(TX_MSG)
        oled.fill(0)
        oled.text("TX:", 0, 0)
        oled.text(TX_MSG.strip()[:16], 0, 16)
        oled.show()

    if e2 == 1:
        show_text(oled, "2")
        toggle_led(led)

    if e3 == 1:
        show_text(oled, "3")
        toggle_led(led)

    time.sleep_ms(POLL_MS)
