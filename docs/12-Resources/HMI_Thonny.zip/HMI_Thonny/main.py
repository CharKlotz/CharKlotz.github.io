# main.py

from machine import Pin, I2C, UART
import time
import ssd1306

DEBOUNCE_MS = 40
POLL_MS = 5

BTN_DOWN_PIN = 9     # swapped
BTN_SEL_PIN = 11
BTN_UP_PIN = 13      # swapped

SCL_PIN = 38
SDA_PIN = 39

LED_PIN = 15

OLED_WIDTH = 128
OLED_HEIGHT = 64
OLED_ADDR = 0x3C

UART_RX_PIN = 44
UART_TX_PIN = 43
UART_BAUD = 9600

LINE_H = 8
MENU_AREA_H = 40
RX_AREA_Y = 40
RX_AREA_H = 24

MENU_TITLE = "Main Menu"
MENU_VISIBLE_ITEMS = 4
text = ""


class DebouncedInput:
    def __init__(self, pin_num, debounce_ms=DEBOUNCE_MS):
        self.pin = Pin(pin_num, Pin.IN, Pin.PULL_DOWN)
        self.debounce_ms = debounce_ms
        self._stable_state = self.pin.value()
        self._last_raw = self._stable_state
        self._last_change = time.ticks_ms()

    def update(self, now_ms):
        raw = self.pin.value()

        if raw != self._last_raw:
            self._last_raw = raw
            self._last_change = now_ms

        if raw != self._stable_state:
            if time.ticks_diff(now_ms, self._last_change) >= self.debounce_ms:
                self._stable_state = raw
                return self._stable_state

        return None


def clear_menu_area():
    oled.fill_rect(0, 0, OLED_WIDTH, MENU_AREA_H, 0)


def clear_rx_area():
    oled.fill_rect(0, RX_AREA_Y, OLED_WIDTH, RX_AREA_H, 0)


def draw_menu():
    clear_menu_area()
    oled.text(MENU_TITLE, 0, 0)

    start = menu_offset
    for row in range(MENU_VISIBLE_ITEMS):
        idx = start + row
        if idx >= len(menu_items):
            break

        y = LINE_H * (row + 1)
        prefix = ">" if idx == menu_index else " "
        label = menu_items[idx]["label"][:15]
        oled.text(prefix + label, 0, y)

    oled.show()


def draw_rx(message):
    clear_rx_area()
    oled.text("RX:", 0, RX_AREA_Y)

    if message:
        oled.text(message[:16], 0, RX_AREA_Y + LINE_H)
        oled.text(message[16:32], 0, RX_AREA_Y + LINE_H * 2)

    oled.show()


def set_rx_message(message):
    global rx_message
    rx_message = message
    draw_rx(rx_message)


def move_menu(delta):
    global menu_index, menu_offset

    new_index = menu_index + delta
    if new_index < 0 or new_index >= len(menu_items):
        return

    menu_index = new_index

    if menu_index < menu_offset:
        menu_offset = menu_index
    elif menu_index >= menu_offset + MENU_VISIBLE_ITEMS:
        menu_offset = menu_index - MENU_VISIBLE_ITEMS + 1

    draw_menu()


def select_item():
    item = menu_items[menu_index]
    print("SELECT:", item["label"])
    item["action"]()
    draw_menu()


# Inputs
btn_down = DebouncedInput(BTN_DOWN_PIN)
btn_sel = DebouncedInput(BTN_SEL_PIN)
btn_up = DebouncedInput(BTN_UP_PIN)

# LED (unused now, but kept initialized)
led = Pin(LED_PIN, Pin.OUT)
led.value(0)

# I2C + OLED
i2c = I2C(0, scl=Pin(SCL_PIN), sda=Pin(SDA_PIN), freq=100000)
oled = ssd1306.SSD1306_I2C(OLED_WIDTH, OLED_HEIGHT, i2c, addr=OLED_ADDR)

# ----- ACTIONS -----

def action_send_azct():
    uart.write(b"AZCTHelloYB")


def action_send_123():
    uart.write(b"123")


def action_send_commandtest():
    uart.write(b"AZTCcommandYB")


def action_clear_rx():
    global rx_buf, rx_message
    rx_buf = b""
    rx_message = ""
    set_rx_message("")


def action_ping():
    uart.write(b"PING")

# UART
uart = UART(2, baudrate=UART_BAUD, tx=Pin(UART_TX_PIN), rx=Pin(UART_RX_PIN))
rx_buf = b""
rx_message = ""

menu_items = [
    {"label": "Send AZCT", "action": action_send_azct},
    {"label": "Send 123", "action": action_send_123},
    {"label": "Send commandTst", "action": action_send_commandtest},
    {"label": "Clear RX", "action": action_clear_rx},
    {"label": "Ping UART", "action": action_ping},
]

menu_index = 0
menu_offset = 0

draw_menu()
draw_rx("Ready")
    
            # CHANGE MENU ITEMS AND ACTIONS SIMULTANEOUSLY
    
while True:
    now = time.ticks_ms()

    # update buttons
    e_up = btn_up.update(now)
    e_sel = btn_sel.update(now)
    e_down = btn_down.update(now)

    # menu behavior
    if e_up == 1:
        move_menu(-1)

    if e_down == 1:
        move_menu(1)

    if e_sel == 1:
        select_item()


    # Recieve RX data
    if uart.any():
        data = uart.read()
        if data:
            rx_buf += data
            # Show whatever has arrived so far
            text_now = rx_buf.decode("utf-8", "ignore").strip()
            if text_now:
                print("RX:", text_now)
                set_rx_message(text_now)

            # Use YB to mark end of message
            while b"YB" in rx_buf:
                idx = rx_buf.find(b"YB")
                message_bytes = rx_buf[:idx + 2]
                rx_buf = rx_buf[idx + 2:]

                # If 4th letter is not C (Not for me) Pass forward
                if len(message_bytes) < 4 or message_bytes[3] != ord('C'):
                    uart.write(message_bytes)

                # decode into processable variable (text)
                text = message_bytes.decode("utf-8", "ignore")
                print("RX:", text)
                set_rx_message(text)
                
                
                
                
    # COMMAND PROCESSING
    if text == "AZTCcommandYB":
        print('do something here once')
        text = ""
        
    time.sleep_ms(POLL_MS)